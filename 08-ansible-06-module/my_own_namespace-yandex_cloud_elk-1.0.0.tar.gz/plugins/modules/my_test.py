#!/usr/bin/python
from ansible.module_utils.basic import AnsibleModule
import os

def run_module():
    # Шаг 3: Параметры path и content
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True),
        state=dict(type='str', default='present', choices=['present', 'absent'])
    )

    result = dict(
        changed=False,
        message=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']
    state = module.params['state']

    if state == 'present':
        # Проверяем, нужно ли что-то менять (идемпотентность)
        if os.path.exists(path):
            with open(path, 'r') as f:
                current_content = f.read()
            if current_content == content:
                module.exit_json(**result) # Ничего не меняем
        
        # Если файла нет или контент другой
        if module.check_mode:
            module.exit_json(changed=True)
        
        with open(path, 'w') as f:
            f.write(content)
        
        result['changed'] = True
        result['message'] = f"File created at {path}"

    elif state == 'absent':
        if os.path.exists(path):
            if module.check_mode:
                module.exit_json(changed=True)
            os.remove(path)
            result['changed'] = True
        else:
            result['changed'] = False

    module.exit_json(**result)

def main():
    run_module()

if __name__ == '__main__':
    main()
